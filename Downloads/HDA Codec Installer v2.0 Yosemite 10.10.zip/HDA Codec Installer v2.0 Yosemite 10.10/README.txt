Hello Everyone

This project dedicated to giving a finite solution to Hackintosh like we are having in other operating Systems like- Windows and Linux.

this guide based on my knowledge and experience gained myself doing so many patches and details from the web. 
Hoping this could help many people looking to  their Audio or Sound solution by themselves.
    
                                
HDA Codec Installer v2.2 Yosemite 10.10.2 ::

It features a collection of automagically installation of  Patched AppleHDA for Audio Codec in Hackintosh. 
This will sort out your audio related problems in Hackintosh . After installation you will get your Sound working.
You just need to change Layout_ID as per mentioned in README after installation it will be on desktop.

Contribution to Project ::

Please provide or send Codec.text file which will automatically create after successful installation . just Email or PM to Me.
Please contribute to project so it can supports wide range of Laptop and Desktops 


TroubelShoot::
Please read troubleshoot file 